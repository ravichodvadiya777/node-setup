var express = require("express");
var router = express.Router();
const Model = require("../model/user");
const Comman = require("../middleware/comman");
const bcrypt = require("bcrypt");
const { authenticateToken } = require("../middleware/verifyToken");

router.post("/signup", async function (req, res, next) {
  try {
    const { name, email, password } = req.body;
    const checkEmail = await Comman.uniqueEmail(Model, email);
    if (!checkEmail) {
      return res.send({
        status: 409,
        success: false,
        message: "This email address already exists.",
      });
    }
    const hashPassword = await bcrypt.hash(password || null, 10);
    const user = await Model.create({
      name,
      email,
      password: hashPassword,
    });
    res.send({
      status: 201,
      success: true,
      message: "User add successfull.",
      data: user,
    });
  } catch (error) {
    console.log(error);
    return res.send({
      status: 400,
      success: false,
      message: "Something not right, please try again.",
    });
  }
});

router.post("/signin", async function (req, res, next) {
  try {
    const { email, password } = req.body;
    const check = await Model.findOne({ email: email }).select("+password");
    if (!check || check.isDeleted) {
      return res.send({
        status: 404,
        success: false,
        message: "user does not exist.",
      });
    }
    if (check.isActive == false) {
      return res.send({
        status: 401,
        success: false,
        message:
          "Your account is deactivated. Please contact the admin for assistance.",
      });
    }
    if (!(await bcrypt.compare(password, check.password)))
      return res.send({
        status: 401,
        success: false,
        message: "Incorrect password or email.",
      });
    delete check._doc.password;
    // generate tokens
    const accessToken = await check.generateAuthToken();
    check._doc.token = accessToken;
    check.invitationStatus = 1;
    await check.save();
    return res.send({
      status: 200,
      success: true,
      message: "Login successfully.",
      data: check,
    });
  } catch (error) {
    console.log(error);
  }
});

router.get("/", authenticateToken, async function (req, res, next) {
  try {
    console.log(req.user, "--------------user");
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
