let Comman = {};
Comman.uniqueEmail = async (model, email) => {
  try {
    const checkEmail = await model.findOne({ email: email });
    if (checkEmail) {
      return false;
    }
    return true;
  } catch (error) {
    console.log(error);
  }
};

module.exports = Comman;
